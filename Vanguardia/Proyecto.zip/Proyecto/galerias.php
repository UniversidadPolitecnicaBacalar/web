<!DOCTYPE html>
<html lang= "es">
    <head>
        <meta charset="UTF-8">
        <title>PROYECTO</title>
        <link rel="stylesheet" href="css/estilo.css"/>
        <link rel="stylesheet" href="css/estiloGalerias.css"/>
        
    </head>
<body>
    <form id="searchform">
        <input type="text" placeholder="Buscar aqu&iacute;..." required>
        <button type="submit">Buscar</button>
    </form>

    <div id="wrapper">
        <header>
            <img id="fondo" src= "images/VANGCON.png" alt="VANGCON">
        </header>
        <ul class="nav">
            <li><a href="index.php">Inicio</a></li>
            <li><a href="quienes_somos.php">Quienes Somos</a>
                <ul>
                    <li><a href="quienes_somos.php">Que es La Vanguardia Juvenil Agrarista</a></li>
                    <li><a href="funciones.php">Nuestra Funcion</a></li>
                    <li><a href="objetivos.php">Nuestros Objetivos</a></li>
                    <li><a href="organizaciones.php">Organizaciones Afiliadas</a></li>
                </ul>
            </li>
            <li><a href="actividades.php">Publicacion de Actividades</a></li>
            <li><a href="galerias.php">VJA en tu Comunidad</a></li>
            <li><a href="directorio.php">Contacto</a>
                <ul>
                    <li><a href="directorio.php">Directorio</a></li>
                    <li><a href="contactanos.php">Contactanos</a></li>
                    <li><a href="suscribete.php">Suscribete</a></li>
                </ul>
            </li>
        </ul>

        <div id="contenedor">
        <aside>
            <div class= "ventana">
                    <figure>
                        <img src="images/Bacalar.png" alt="Bacalar">
                    </figure>
            </div> 

            <div class="ventana2">
                <figure>
                    <img src="images/Logo.png" alt="Logo">
                </figure>
            </div>
        </aside>
        
        <section>
            <article>
                <div id="galeria">
                    <p id="title">Certamen <br> "La Flor mas Bella del Campo 2015" </p>
                    <div id="galeria_imagen">
                        <img id="imgGaleria" src="images2/4.jpg"/></div>
                        <div id="galeria_miniaturas">
                            <img class="miniatura" onclick="javascript:document.getElementById('imgGaleria').src=this.src;" src="images2/3.jpg"/>
                            <img class="miniatura" onclick="javascript:document.getElementById('imgGaleria').src=this.src;" src="images2/5.jpg"/>
                            <img class="miniatura" onclick="javascript:document.getElementById('imgGaleria').src=this.src;" src="images2/10.jpg"/>
                            <img class="miniatura" onclick="javascript:document.getElementById('imgGaleria').src=this.src;" src="images2/8.jpg"/>
                            <img class="miniatura" onclick="javascript:document.getElementById('imgGaleria').src=this.src;" src="images2/11.jpg"/>
                        </div>
                </div>
                <div id="galeria2">
                    <p id="title2">Rally en Bacalar </p>
                    <div id="galeria_imagen2">
                        <img id="imgGaleria2" src="images2/rally6.jpg"/></div>
                        <div id="galeria_miniaturas2">
                            <img class="miniatura2" onclick="javascript:document.getElementById('imgGaleria2').src=this.src;" src="images2/rally1.jpg"/>
                            <img class="miniatura2" onclick="javascript:document.getElementById('imgGaleria2').src=this.src;" src="images2/rally2.jpg"/>
                            <img class="miniatura2" onclick="javascript:document.getElementById('imgGaleria2').src=this.src;" src="images2/rally3.jpg"/>
                            <img class="miniatura2" onclick="javascript:document.getElementById('imgGaleria2').src=this.src;" src="images2/rally4.jpg"/>
                            <img class="miniatura2" onclick="javascript:document.getElementById('imgGaleria2').src=this.src;" src="images2/rally5.jpg"/>
                        </div>
                </div>
            </article>
            <br>
            <article>
                <div id="galeria3">
                    <p id="title3">Toma de Protesta por la Presidencia de <br> Vanguardia Juvenil Agrarista Bacalar <br> por Ing. Moises Gonzalez Carrillo </p>
                    <div id="galeria_imagen3">
                        <img id="imgGaleria3" src="images2/protesta2.jpg"/></div>
                        <div id="galeria_miniaturas3">
                            <img class="miniatura3" onclick="javascript:document.getElementById('imgGaleria3').src=this.src;" src="images2/protesta.jpg"/>
                            <img class="miniatura3" onclick="javascript:document.getElementById('imgGaleria3').src=this.src;" src="images2/protesta1.jpg"/>
                            <img class="miniatura3" onclick="javascript:document.getElementById('imgGaleria3').src=this.src;" src="images2/protesta3.jpg"/>
                            <img class="miniatura3" onclick="javascript:document.getElementById('imgGaleria3').src=this.src;" src="images2/protesta4.jpg"/>
                            <img class="miniatura3" onclick="javascript:document.getElementById('imgGaleria3').src=this.src;" src="images2/protesta5.jpg"/>
                            <img class="miniatura3" onclick="javascript:document.getElementById('imgGaleria3').src=this.src;" src="images2/protesta6.jpg"/>
                        </div>
                </div>
            </article>

        </section>

        </div>
    </div><!--Fin del Wraper-->

    <div id="footer">
            <p id="nav_alt"> <a href="index.php" title="Inicio">Inicio</a> | <a href="quienes_somos.php" title="Quiénes Somos">Quiénes Somos</a> | <a href="actividades.php" title="Actividades">Publicacion de Actividades</a> | <a href="galerias.php" title="VJA en tu Comunidad">VJA en Tu Comunidad</a> | <a href="contactanos.php" title="Contactanos">Contactanos</a> | <a href="politica-de-privacidad.php" title="Política de privacidad">Politcas de Privacidad</a> </p>
    </div>

</body>
</html>