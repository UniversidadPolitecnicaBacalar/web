<?php
if(isset($_POST['nombre']) && !empty($_POST['nombre']) &&
	isset($_POST['apellido']) && !empty($_POST['apellido']) &&
	isset($_POST['edad']) && !empty($_POST['edad']) &&
	isset($_POST['municipio']) && !empty($_POST['municipio']) &&
	isset($_POST['email']) && !empty($_POST['email']) &&
	isset($_POST['telefono']) && !empty($_POST['telefono']) &&
	isset($_POST['genero']) && !empty($_POST['genero']) &&
	isset($_POST['fecha_nac']) && !empty($_POST['fecha_nac'])){

	//Recuperar datos del formulario
	$nombre = $_POST['nombre'];
	$apellido = $_POST['apellido'];
	$edad = $_POST['edad'];
	$municipio = $_POST['municipio'];
	$email = $_POST['email'];
	$telefono = $_POST['telefono'];
	$genero = $_POST['genero'];
	$fecha_nac = $_POST['fecha_nac'];

	//Crear la conexion SERVER, USR, PAS, DB
	$conexion = mysqli_connect("localhost","root","","vanguardia");
	mysqli_set_charset($conexion,"utf8");

	//Verifico mi conexion
	if(!$conexion) {
		die("Error en la conexion: " . mysql_connect_error());
	} else {
		$sql = " INSERT INTO suscripcion (nombre, apellido, edad, municipio, email, telefono, genero, fecha_nac) VALUES ('$nombre','$apellido', '$edad', '$municipio', '$email','$telefono', '$genero', '$fecha_nac')";
		if (mysqli_query($conexion,$sql)){
			echo "<script type='text/javascript'>";
			echo "window.alert('Datos alamcenados correctamente !!.');";
			echo "location.href='index.php'";
			echo "</script>";
		}
	}
}
else{
	echo"<script type='text/javascript'>";
    echo"window.alert('Algunos Campos estan Vacios.');";
    echo"</script>";
}