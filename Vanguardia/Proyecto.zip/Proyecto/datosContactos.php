<?php

if (isset($_POST['nombre']) && !empty($_POST['nombre']) &&
    isset($_POST['apellido']) && !empty($_POST['apellido']) && 
    isset($_POST['organizacion_name']) && !empty($_POST['organizacion_name']) &&
    isset($_POST['ciudad']) && !empty($_POST['ciudad']) &&
    isset($_POST['email']) && !empty($_POST['email']) &&
    isset($_POST['asunto']) && !empty($_POST['asunto']) &&
    isset($_POST['mensaje']) && !empty($_POST['mensaje'])){

	//Recuperar datos del formulario
	$nombre = $_POST['nombre'];
	$apellido = $_POST['apellido'];
	$organizacion_name = $_POST['organizacion_name'];
	$ciudad= $_POST['ciudad'];
	$email = $_POST['email'];
	$asunto = $_POST['asunto'];
	$mensaje = $_POST['mensaje'];
	 
	 //Crear la conexcion SERVER, USR, PASS, DB
	$conexion = mysqli_connect("localhost","root","","vanguardia");
	mysqli_set_charset($conexion,"utf8"); //Para los acentos

	//Verifico mi conexion
	if (!$conexion) {
		die("Error en la conexion: " . mysql_connect_error());
	} else {
		$sql = "INSERT INTO contactanos (nombre, apellido, organizacion_name, ciudad, email, asunto,mensaje) VALUES ('$nombre','$apellido','$organizacion_name','$ciudad','$email','$asunto','$mensaje')";
		if (mysqli_query($conexion,$sql)){
			echo"<script type='text/javascript'>";
		    echo"window.alert('Datos enviados correctamente.');";
		    echo"location.href='index.php'";
		    echo"</script>";
		}
}
}
else{
	echo"<script type='text/javascript'>";
    echo"window.alert('Algunos Campos estan Vacios.');";
    echo"</script>";
}
?>