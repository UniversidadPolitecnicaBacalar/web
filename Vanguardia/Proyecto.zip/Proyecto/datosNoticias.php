<?php
    if(isset($_POST['fecha']) && !empty($_POST['fecha']) &&
        isset($_POST['titulo']) && !empty($_POST['titulo']) &&
        isset($_POST['noticia']) && !empty($_POST['noticia']) &&
        isset($_POST['email']) && !empty($_POST['email'])){

        //recupero variables
        $fecha = $_POST['fecha'];
        $titulo = $_POST['titulo'];
        $noticia = $_POST['noticia'];        
        $email = $_POST['email'];
        //Crear la conexion a la bd
        $conexion = mysql_connect("localhost","root","");
        mysql_select_db("vanguardia");

        //verifico mi conexion
        if(!$conexion){
        	die("Error en la conexion: " . mysql_error());
        } else {
        	$query = mysql_query("SELECT email FROM directorio WHERE email = '$email'") or die(mysql_error());
            $result = mysql_fetch_assoc($query);
        	if ($result['email'] !=$email) {
        		echo"<script type='text/javascript'>";
    		    echo"window.alert('Lo Sentimos, No puedes Publicar debes ser Administrador');";
    		    echo"</script>";
        	}else{
        		$sql = "INSERT INTO noticias (fecha,titulo,noticia,email) VALUES ('$fecha','$titulo','$noticia','$email')";
        		if (mysql_query($sql)) {
        			echo"<script type='text/javascript'>";
    			    echo"window.alert('Noticia Publicada Satisfactoriamente');";
    			    echo"location.href='actividades.php'";
    			    echo"</script>";
        		}
        	}
        }
}else {
    	echo"<script type='text/javascript'>";
        echo"window.alert('Debe llenar todos los Datos Administrador.');";
        echo"</script>";
    }
?>  