<!DOCTYPE html>
<html lang= "es">
    <head>
        <meta charset="UTF-8">
        <title>PROYECTO</title>
        <link rel="stylesheet" href="css/estilo.css"/>
    </head>
<body>
    <form id="searchform">
        <input type="text" placeholder="Buscar aqu&iacute;..." required>
        <button type="submit">Buscar</button>
    </form>
    <div id="wrapper">
        <header>
            <img id="fondo" src= "images/VANGCON.png" alt="VANGCON">
        </header>
        <ul class="nav">
            <li><a href="index.php">Inicio</a></li>
            <li><a href="quienes_somos.php">Quienes Somos</a>
                <ul>
                    <li><a href="quienes_somos.php">Que es La Vanguardia Juvenil Agrarista</a></li>
                    <li><a href="funciones.php">Nuestra Funcion</a></li>
                    <li><a href="objetivos.php">Nuestros Objetivos</a></li>                    
                    <li><a href="organizaciones.php">Organizaciones Afiliadas</a></li>
                </ul>
            </li>
            <li><a href="actividades.php">Publicacion de Actividades</a></li>
            <li><a href="galerias.php">VJA en tu Comunidad</a></li>
            <li><a href="#">Contacto</a>
                <ul>
                    <li><a href="directorio.php">Directorio</a></li>
                    <li><a href="contactanos.php">Contactanos</a></li>
                    <li><a href="suscribete.php">Suscribete</a></li>
                </ul>
            </li>
        </ul>

        <div id="contenedor">
        <aside>
            <div class= "ventana">
                    <figure>
                        <img src="images/Bacalar.png" alt="Bacalar">
                    </figure>
            </div> 

            <div class="ventana2">
                <figure>
                    <img src="images/Logo.png" alt="Logo">
                </figure>
            </div>
            
            <div class="boletin">                
                    <img src="images/suscribete.jpg" alt="suscribete">
                    <h2 class="textoboletin">Se parte de Nuestras Actividades!</h2>
                    <form action="datosSuscriptores.php" method="POST" id="newsletter">
                           <fieldset>
                        <label class="first">Nombre<br />
                        <input type="text" id="nombre" name="nombre" class="textfield" required=""/>
                        </label>
                        <label>E-mail<br />
                        <input type="text" id="email" name="email" class="textfield2" placeholder="ejemplo@correo.com" required=""/>
                        <lable>
                        <input type="submit" class="submit" value="Continuar"/>
                        </fieldset>
                    </form>
            </div>
            </br>
            <a class="twitter-timeline" data-dnt="true" href="https://twitter.com/VJABACALAR" data-widget-id="625781584789045252">Tweets por el @VJABACALAR.</a>
            <a href='https://twitter.com/VJABACALAR' style='display:scroll;position:fixed;bottom:330px;right:0px;' target='_blank'><img border='0' src='http://2.bp.blogspot.com/-r2kTvDo3bfw/Toc-MKnFfxI/AAAAAAAAA3A/3f86LWBmR38/s1600/boton%252520twitter.png' title='Siguenos en Twitter'/></a>
            <a href='https://www.facebook.com/profile.php?id=100009614793114&fref=ts' style='display:scroll;position:fixed;bottom:185px;right:0px;' target='_blank'><img border='0' src='http://1.bp.blogspot.com/-7VSvlkal0os/UFORwVAFAZI/AAAAAAAAHkg/nhegYirxh5g/s1600/boton+facebook_opt.png' title='Agreganos en Facebook'/></a>
            <a href='URL_De_Google+' style='display:scroll;position:fixed;bottom:41px;right:0px;' target='_blank'><img border='0' src='http://4.bp.blogspot.com/-idti1v7hB8w/UFN_GPFp2NI/AAAAAAAAHjA/16kXdqvAXHQ/s1600/aizumgoogle+.png' title='Seguirnos en Google+'/></a>
        </aside>

        <!--Comienza el contenido de la pagina-->
        <section>
            <article>
                <h2 id="bienvenida">ORGANIZACIONES AFILIADAS</h2>
            </article>
            <article>
                    <a href="http://pri.org.mx/TransformandoaMexico/inicio.aspx" target="_blank"><img class="logos" src="images/Logo.png" alt="Logo"></a><br>
                    <a href="http://www.copppal.org/" target="_blank"><img class="logos" src="images/Copppal.jpg" alt="Copppal"></a><br>
                    <a href="http://www.cnc.org.mx/" target="_blank"><img class="logos" src="images/campesinos.jpg" alt="campesinos"></a><br>
                    <a href="http://www.socialistinternational.org/" target="_blank"><img class="logos" src="images/InternacionalSocialista.jpg" alt="InternacionalSocialista"></a>
            </article>
            <br>
        </section>
        </div>
    </div><!--Fin del Wraper-->

    <div id="footer">
            <p id="nav_alt"> <a href="index.php" title="Inicio">Inicio</a> | <a href="quienes_somos.php" title="Quiénes Somos">Quiénes Somos</a> | <a href="actividades.php" title="Actividades">Publicacion de Actividades</a> | <a href="galerias.php" title="VJA en tu Comunidad">VJA en Tu Comunidad</a> | <a href="contactanos.php" title="Contactanos">Contactanos</a> | <a href="politica-de-privacidad.php" title="Política de privacidad">Politcas de Privacidad</a> </p>
    </div>

</body>
</html>