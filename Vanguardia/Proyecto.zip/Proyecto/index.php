<!DOCTYPE html>
<html lang= "es">
    <head>
        <meta charset="UTF-8">
        <title>PROYECTO</title>
        <link rel="stylesheet" href="css/estilo.css"/>
        <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
        <script src="js/jquery.min.js"></script>
        <script src="js/jquery.zaccordion.min.js"></script>
        <style type="text/css">
            /* Just some styles to set the page layout. */            
            small {font-size:11px;margin:15px 0;color:#333;}
            p span {color:black;}
            #container {width:700px; float:right;position: relative;}
            #examples{padding-left: 150px;}
            .clear {clear:both;}
        </style>
        <script type="text/javascript">
            $(document).ready(function() {
                $("pre.js").each(function(index) {
                    eval($(this).text());
                });
            });
        </script>
    </head>
<body>
    <form action="datosBuscar.php" method="post" id="searchform">
        <input type="text" id="buscar" name="buscar" placeholder="Buscar aqui" required>
        <button type="submit">Buscar</button>
    </form>
    <div id="wrapper">
        <header>
            <img id="fondo" src= "images/VANGCON.png" alt="VANGCON">
        </header>
        <ul class="nav">
            <li><a href="index.php">Inicio</a></li>
            <li><a href="quienes_somos.php">Quienes Somos</a>
                <ul>
                    <li><a href="quienes_somos.php">Que es La Vanguardia Juvenil Agrarista</a></li>
                    <li><a href="funciones.php">Nuestra Funcion</a></li>
                    <li><a href="objetivos.php">Nuestros Objetivos</a></li>                    
                    <li><a href="organizaciones.php">Organizaciones Afiliadas</a></li>
                </ul>
            </li>
            <li><a href="actividades.php">Publicacion de Actividades</a></li>
            <li><a href="galerias.php">VJA en tu Comunidad</a></li>
            <li><a href="directorio.php">Contacto</a>
                <ul>
                    <li><a href="directorio.php">Directorio</a></li>
                    <li><a href="contactanos.php">Contactanos</a></li>
                    <li><a href="suscribete.php">Suscribete</a></li>
                </ul>
            </li>
        </ul>

        <div id="contenedor">
        <aside>
            <div class= "ventana">
                    <figure>
                        <img src="images/Bacalar.png" alt="Bacalar">
                    </figure>
            </div> 

            <div class="ventana2">
                <figure>
                    <img src="images/Logo.png" alt="Logo">
                </figure>
            </div>
            
            <div class="boletin">                
                    <img src="images/suscribete.jpg" alt="suscribete">
                    <h2 class="textoboletin">Se parte de Nuestras Actividades!</h2>
                    <form action="suscribete.php" method="POST" id="newsletter">
                        <fieldset>
                        <label class="first">Nombre<br />
                        <input type="text" id="nombre" name="nombre" class="textfield" required=""/>
                        </label>
                        <label>E-mail<br />
                        <input type="text" id="email" name="email" class="textfield2" placeholder="ejemplo@correo.com" required=""/>
                        <lable>
                        <input type="submit" class="submit" value="Continuar"/>
                        </fieldset>
                    </form>
            </div>
            </br>
            <a href='https://twitter.com/VJABACALAR' style='display:scroll;position:fixed;bottom:330px;right:0px;' target='_blank'><img border='0' src='http://2.bp.blogspot.com/-r2kTvDo3bfw/Toc-MKnFfxI/AAAAAAAAA3A/3f86LWBmR38/s1600/boton%252520twitter.png' title='Siguenos en Twitter'/></a>
            <a href='https://www.facebook.com/profile.php?id=100009614793114&fref=ts' style='display:scroll;position:fixed;bottom:185px;right:0px;' target='_blank'><img border='0' src='http://1.bp.blogspot.com/-7VSvlkal0os/UFORwVAFAZI/AAAAAAAAHkg/nhegYirxh5g/s1600/boton+facebook_opt.png' title='Agreganos en Facebook'/></a>
            <a href='URL_De_Google+' style='display:scroll;position:fixed;bottom:41px;right:0px;' target='_blank'><img border='0' src='http://4.bp.blogspot.com/-idti1v7hB8w/UFN_GPFp2NI/AAAAAAAAHjA/16kXdqvAXHQ/s1600/aizumgoogle+.png' title='Seguirnos en Google+'/></a>
        </aside>

        <!--Comienza el contenido de la pagina-->
        <section>
            <article>
                <h2 id="bienvenida">BIENVENIDO, CONOCE VANGUARDIA JUVENIL AGRARISTA BACALAR </h2>
            </article>
            <br>
            <article>
                <p id="texto">En <font class="letras">Vanguardia Juvenil Agrarista</font> reconocemos que los cambios en la dinámica social se acompañan de nuevas
formas de relación y organización entre las personas, aprovechando el progreso técnico alcanzado por el hombre. 
Es por lo anterior que refrendemos el compromiso que ha caracterizado la acción de nuestra organización,
dando primicia al derecho a la información.  
Es por eso, que ponemos a su disposición este espacio dedicado a la difusión e integración 
de todos los comprometidos con nuestra causa, por el cual pretendemos ofrecer informacion de la Vanguardia Juvenil Agrarista  y su proyección al exterior.
Esperando que este medio cumpla con su cometido y que sea un canal eficiente con el cual estrechar aún más los lazos de cooperación 
y trabajo en conjunto que caracterizan a la Vanguardia Juvenil Agrarista.</p>
            </article>
            <br>
            <article>
            <div id="container">
                <div id="examples">
                    <ul id="example1">
                        <li>
                            <img src="images/imagen3.jpg" width="600" height="270" alt="imagen3" />
                        </li>
                        <li>
                            <img src="images/imagen4.jpg" width="600" height="270" alt="imagen4" />
                        </li>
                        <li>
                            <img src="images/imagen1.jpg" width="600" height="270" alt="imagen1" />
                        </li>
                        <li>
                            <img src="images/imagen2.jpg" width="600" height="270" alt="imagen2" />
                        </li>
                    </ul>
                </div>
            </div>
<script type="text/javascript">
    $("#example1").zAccordion({
        timeout: 4000,
        slideWidth: 600,
        width: 700,
        height: 290,
    });
</script>
            </article>
            <article>
                <div id="novedades">
                    <h2 id="bienvenida3">NOVEDADES MAS RECIENTES... </h2>
                </div>
<?php
   $conexion = mysql_connect("localhost","root","");
    mysql_select_db("vanguardia");

    //verifico mi conexion
    if(!$conexion){
        die("Error en la conexion: " . mysql_error());
    }
     $resultado = mysql_query("SELECT fecha,titulo,noticia FROM noticias ORDER BY fecha DESC LIMIT 3");
            while ($row=mysql_fetch_array($resultado)) {
                echo "<br>";
                echo "<div id='notPublicada'>";
                echo "<p class='new'>Fecha: $row[fecha]</p>";
                echo "<p class='title'>Titulo: $row[titulo]</p>";
                echo "<p class='new2'>$row[noticia]</p>";
                echo "</div>";
                echo "<br>";
            }

?>
            </article>
        </section>
        </div>
    </div><!--Fin del Wraper-->

    <div id="footer">
            <p id="nav_alt"> <a href="index.php" title="Inicio">Inicio</a> | <a href="quienes_somos.php" title="Quiénes Somos">Quiénes Somos</a> | <a href="actividades.php" title="Actividades">Publicacion de Actividades</a> | <a href="galerias.php" title="VJA en tu Comunidad">VJA en Tu Comunidad</a> | <a href="contactanos.php" title="Contactanos">Contactanos</a> | <a href="politica-de-privacidad.php" title="Política de privacidad">Politcas de Privacidad</a> </p>
    </div>

</body>
</html>