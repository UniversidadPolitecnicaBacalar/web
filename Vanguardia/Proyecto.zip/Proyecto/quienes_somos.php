<!DOCTYPE html>
<html lang= "es">
    <head>
        <meta charset="UTF-8">
        <title>PROYECTO</title>
        <link rel="stylesheet" href="css/estilo.css"/>
    </head>
<body>
    <form id="searchform">
        <input type="text" placeholder="Buscar aqu&iacute;..." required>
        <button type="submit">Buscar</button>
    </form>
    <div id="wrapper">
        <header>
            <img id="fondo" src= "images/VANGCON.png" alt="VANGCON">
        </header>
        <ul class="nav">
            <li><a href="index.php">Inicio</a></li>
            <li><a href="quienes_somos.php">Quienes Somos</a>
                <ul>
                    <li><a href="quienes_somos.php">Que es La Vanguardia Juvenil Agrarista</a></li>
                    <li><a href="funciones.php">Nuestra Funcion</a></li>
                    <li><a href="objetivos.php">Nuestros Objetivos</a></li>                    
                    <li><a href="organizaciones.php">Organizaciones Afiliadas</a></li>
                </ul>
            </li>
            <li><a href="actividades.php">Publicacion de Actividades</a></li>
            <li><a href="#">VJA en tu Comunidad</a></li>
            <li><a href="directorio.php">Contacto</a>
                <ul>
                    <li><a href="directorio.php">Directorio</a></li>
                    <li><a href="contactanos.php">Contactanos</a></li>
                    <li><a href="suscribete.php">Suscribete</a></li>
                </ul>
            </li>
        </ul>

        <div id="contenedor">
        <aside>
            <div class= "ventana">
                    <figure>
                        <img src="images/Bacalar.png" alt="Bacalar">
                    </figure>
            </div> 

            <div class="ventana2">
                <figure>
                    <img src="images/Logo.png" alt="Logo">
                </figure>
            </div>
            
            <div class="boletin">                
                    <img src="images/suscribete.jpg" alt="suscribete">
                    <h2 class="textoboletin">Se parte de Nuestras Actividades!</h2>
                    <form action="suscribete.php" method="POST" id="newsletter">
                        <fieldset>
                        <label class="first">Nombre<br />
                        <input type="text" id="nombre" name="nombre" class="textfield" required=""/>
                        </label>
                        <label>E-mail<br />
                        <input type="text" id="email" name="email" class="textfield2" placeholder="ejemplo@correo.com" required=""/>
                        <lable>
                        <input type="submit" class="submit" value="Continuar"/>
                        </fieldset>
                    </form>
            </div>
            </br>
            <a href='https://twitter.com/VJABACALAR' style='display:scroll;position:fixed;bottom:330px;right:0px;' target='_blank'><img border='0' src='http://2.bp.blogspot.com/-r2kTvDo3bfw/Toc-MKnFfxI/AAAAAAAAA3A/3f86LWBmR38/s1600/boton%252520twitter.png' title='Siguenos en Twitter'/></a>
            <a href='https://www.facebook.com/profile.php?id=100009614793114&fref=ts' style='display:scroll;position:fixed;bottom:185px;right:0px;' target='_blank'><img border='0' src='http://1.bp.blogspot.com/-7VSvlkal0os/UFORwVAFAZI/AAAAAAAAHkg/nhegYirxh5g/s1600/boton+facebook_opt.png' title='Agreganos en Facebook'/></a>
            <a href='URL_De_Google+' style='display:scroll;position:fixed;bottom:41px;right:0px;' target='_blank'><img border='0' src='http://4.bp.blogspot.com/-idti1v7hB8w/UFN_GPFp2NI/AAAAAAAAHjA/16kXdqvAXHQ/s1600/aizumgoogle+.png' title='Seguirnos en Google+'/></a>
        </aside>

        <!--Comienza el contenido de la pagina-->
        <section>
            <article>
                <img id="logotext" src="images/campesinos.jpg" align="center">
                <img id="slogan" src="images/slogan.jpg" align="center">
                <img id="logotext2" src="images/vanggen.jpg" align="center">
                <h2 id="bienvenida2">VANGUARDIA JUVENIL AGRARISTA BACALAR </h2>
            </article>
            <article>
                <p id="texto2">La <font class="letras">Vanguardia Juvenil Agrarista</font> es un organismo social dotado de personalidad jurídica y patrimonio propio, es la organización clasista y mayoritaria de la juventud campesina que tiene como principal objeto impulsar el desarrollo integral de  sus miembros cuya edad fluctúa entre los 18 y 35 años, fundada el 10 de Abril de 1969 como organismo Filial Juvenil de la Confederación Nacional Campesina.
Es por lo anterior que  refrendo el  compromiso por el campo mexicano, mismo que se ha caracterizado por ser el forjador de grandes hombres, como lo fue el            Gral. Emiliano Zapata “El Caudillo del Sur” y el gran líder local Don Serapio Flota Maas, dos de los muchos hombres nacidos del campo mexicano, que dieron su vida por defender los ideales de los campesinos. Motivo por el que encauzare la acción de nuestra organización, a la defensa de las prerrogativas rurales, por lo que doy primicia al derecho a la información, derecho que considero pilar para la construcción de este joven municipio. 
Bacalar es un 80% rural, motivo por el cual pongo a la disposición de nuestros militantes y de los interesados en general; un espacio dedicado a la difusión e integración  de todos aquellos programas y proyectos de fomento al campo comprometidos con nuestra causa,  por medio del cual pretendo ofrecer una alternativa más para la retroalimentación de las propuestas al interior de la Vanguardia Juvenil Agrarista  y su proyección al exterior.
</p>
                <p id="texto3">A T E N T A M E N T E 
                    “Tierra y Libertad”</p>
                <p id="texto4">ING. MOISES ALEJANDRO GONZALEZ CARRILLO
PRESIDENTE DEL CDM DE LA VANGUARDIA JUVENIL AGRARISTA</p                    
            </article>
            <br>
        </section>
        </div>
    </div><!--Fin del Wraper-->

    <div id="footer">
            <p id="nav_alt"> <a href="index.php" title="Inicio">Inicio</a> | <a href="quienes_somos.php" title="Quiénes Somos">Quiénes Somos</a> | <a href="actividades.php" title="Actividades">Publicacion de Actividades</a> | <a href="galerias.php" title="VJA en tu Comunidad">VJA en Tu Comunidad</a> | <a href="contactanos.php" title="Contactanos">Contactanos</a> | <a href="politica-de-privacidad.php" title="Política de privacidad">Politcas de Privacidad</a> </p>
    </div>

</body>
</html>