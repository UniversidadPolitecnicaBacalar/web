<?php
require("Cabeza.php");
?>
				<p><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br></p>
           
<div id="footer4">
      <p>Copyright &copy;</p>
    </footer>
  </div>