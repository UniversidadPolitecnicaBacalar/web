
<?php
require("Cabeza.php");
require("SQL.php");
?>
	
	<?php
	 if($_POST){
		 
		 if($_POST["pass1"] == $_POST["pass2"]){
			$queEmp = "UPDATE `veterinaria`.`usr_usuarios` SET `usr_passwd` = '".$_POST["pass1"]."' WHERE `usr_usuarios`.`usr_username` = '".$_SESSION["Usuario"]."'";
			//echo $queEmp;
			$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error()); 
			echo "<p><h2><b>Modificación de contraseña satisfactoria</b><h2></p>";
			 }
		 else
			echo "<p><h2><b>Las contraseñas no coinciden intente de nuevo</b><h2></p>";
		 
		 }
	 else{	 
	?>
				<p><center>
	<form name="formulario" method="POST" onSubmit='return Connprobacion()' action="EditUsuario.php" class="registro1">
	
	<h2><b>Editar contraseña</b></h2>
	<p><b>Nueva contraseña: </b><input type="password" name="pass1">
	<p><b>Confirmar-Contraseña: </b><input type="password" name="pass2">
	<p><input type="submit" value="Ingresar">
	</form>
				</center></p>
       
     <?php
		}
     ?>  
       
           
<div id="footer3">
      <p>Copyright &copy;</p>
    </footer>
  </div>