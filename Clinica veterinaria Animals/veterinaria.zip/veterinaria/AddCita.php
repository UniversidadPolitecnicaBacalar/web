<?php
require("Cabeza.php");
require("SQL.php");
?>
<?php
	 if($_POST){
		 
		$queEmp = "INSERT INTO `veterinaria`.`cit_cita` (`cit_id`, `cit_fecha`, `cit_hora`, `cit_programacion`, `estado`, `doc_cit_id`, `infm_cit_id`) 
		VALUES (NULL, '".$_POST["Fecha"]."', '".$_POST["Hora"].":00', '".$_POST["Programa"]."', 'Pendiente', '".$_POST["Doctor"]."', '".$_POST["Paciente"]."')";
		//echo $queEmp."<br>";
		$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error()); 
		echo "<p><h2><b>Creacion de la cita</b></h2></p>";
		
	 }
	 else{
	 ?>
	 <div id="main">
     <center><p>
	 <form name="formulario" method="POST" onSubmit='return Connprobacion()' action="AddCita.php" class="registro"> 
	 <h2><b>Añadir cita al sistema</b></h2>
	 <p><b>Fecha (Año-Mes-Dia): </b><input type="text" name="Fecha">
	 <p><b>Hora (Hora:Minuto): </b><input type="text" name="Hora">
	 <p><b>Programa: </b><input type="text" name="Programa">
	 <p><b>Doctor: </b>
		<select name="Doctor">
		<?php
		$queEmp = "SELECT * FROM emp_empleados where car_emp_id = '3'";
		//echo $queEmp;
		$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error());
		while ($row = mysql_fetch_row($resEmp)){
			echo "<option value=".$row[0]." selected>".$row[1]."</option>";
			}
		?>
	</select>
	 <p><b>Paciente: </b>
		<select name="Paciente">
		<?php
		$queEmp = "SELECT * FROM infm_informacion_mascotas";
		//echo $queEmp;
		$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error());
		while ($row = mysql_fetch_row($resEmp)){
			echo "<option value=".$row[0]." selected>".$row[1]."</option>";
			}
		?>
	</select>
	 <p><input type="submit" value="Ingresar">
	 </form>
	 <p></center>
<?php
	}
?>
           
<div id="footer3">
      <p>Copyright &copy;</p>
    </footer>
  </div>