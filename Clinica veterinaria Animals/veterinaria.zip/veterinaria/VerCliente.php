   
<?php
require("Cabeza.php");
require("SQL.php");
?>
	
	<?php
	 	  	$queEmp = "SELECT * FROM `prop_propietarios`";
			//echo $queEmp;
			$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error()); 
			echo "<p><h2><b>Lista de clientes</b></h2></p>";		 
	?>
				<center>
		<?php
		echo "<table>"; 
		echo "<tr><td><b>ID</b></td><td><b>Nombre</b></td><td><b>Apellido</b></td><td><b>Direcion</b></td><td><b>Telefono</b></td></tr> \n"; 
			while ($row = mysql_fetch_row($resEmp)){ 
				echo "<tr>";
				echo "<td>$row[0]</td>";
				echo "<td>$row[1]</td>";
				echo "<td>$row[2]</td>";
				echo "<td>$row[3]</td>";
				echo "<td>$row[4]</td>";
				echo "</tr>"; 
				} 
			echo "</table>"; 
?> 			
		</center>
       
     <?php
		
     ?>  

<div id="footer2">
      <p>Copyright &copy;</p>
    </footer>
  </div>