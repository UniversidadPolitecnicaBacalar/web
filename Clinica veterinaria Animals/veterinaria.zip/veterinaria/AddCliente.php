<?php
require("Cabeza.php");
require("SQL.php");
?>
	
	<?php
	 if($_POST){
		  	$queEmp = "INSERT INTO `veterinaria`.`prop_propietarios` (`prop_id`, `prop_nombre`, `prop_apellido`, `prop_direccion`, `prop_telcasa`, `gen_genero_gen_id`) 
		  	VALUES (null, '".$_POST["Nombre"]."', '".$_POST["Apellido"]."', '".$_POST["Direcion"]."', '".$_POST["TelefonoCasa"]."', '1');";
			//echo $queEmp."<br>";
			$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error()); 
			echo "<br><br><p><h2><b>Creacion de cliente satisfecha</b></h2></p>";
		 }
	 else{	 
	?>
	<div id="main">
				<center><p>
	<form name="formulario" method="POST" onSubmit='return Connprobacion()' action="AddCliente.php" class="registro">
	<div align="center">
	<h2><b>Añadir cliente</b></h2>
	<p><b>Nombre: </b><input type="text" name="Nombre">
	<p><b>Apellido: </b><input type="text" name="Apellido">
	<p><b>Direción: </b><input type="text" name="Direcion">
	<p><b>Telefono: </b><input type="text" name="TelefonoCasa">
	<p><b>Sexo: </b><input type=radio name=SEXO value="1" ><b> masculino </b><input type=radio name=SEXO value="2"><b> femenino </b>
	</div>
	<input type="submit" value="Ingresar">
	</form>
				</p></center>
       
     <?php
		}
     ?>  
       
<div id="footer1">
      <p>Copyright &copy;</p>
    </footer>
  </div>