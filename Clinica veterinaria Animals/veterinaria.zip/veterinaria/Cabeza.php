<?php
session_start(); 
if( empty($_SESSION["Usuario"])) 
{
 session_destroy();
 header("Location: index.html");  
}
?>
<!DOCTYPE HTML>
<html>

<head>
        <meta charset="utf-8"> 
        <title>Veterinaria</title>
        <link rel="shortcut icon" href="images/IMG-20150710-WA0009.jpg"/>
        <link rel="stylesheet" href="css/style.css"/>
        <script type="text/javascript" src="js/modernizr-1.5.min.js">
        </script>
    </head>

<body>
  <div id="main">
    <header>
   
        <img id="logo" src="images/IMG-20150710-WA0009.jpg" alt="Animals" width="172.5">
            <h1 id="idTitulo">Clinica Veterinaria<br>Animals</h1>
      <nav>
        <ul class="sf-menu" id="nav">
          <li><a href="#">Usuario</a>
                <ul>
                  <li><a href="AddUsuario.php">Añadir</a></li>
                  <li><a href="EditUsuario.php">Editar</a></li>
                </ul>
              </li> 
              <li><a href="#">Cliente</a>
                <ul>
                  <li><a href="AddCliente.php">Añadir</a></li>
                  <li><a href="VerCliente.php">Ver</a></li>
                </ul>
              </li> 
              <li><a href="#">Mascotas</a>
                <ul>
                  <li><a href="AddMascota.php">Añadir</a></li>
                  <li><a href="VerMascota.php">Ver</a></li>
                </ul>
              </li> 
              <li><a href="#">Citas</a>
                <ul>
                  <li><a href="AddCita.php">Añadir</a></li>
                  <li><a href="VerCita.php">Ver citas</a></li>
                  <li><a href="Historia.php">Historial</a></li>
                </ul>
              </li> 
          <li>
        
          <a href="CerraSesion.php" title="Cerrar sesión">Salir</a></li>
          
        </ul>
      </nav>
    </header>
            <center>