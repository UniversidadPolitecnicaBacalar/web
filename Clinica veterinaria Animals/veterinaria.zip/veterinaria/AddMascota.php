   
<?php
require("Cabeza.php");
require("SQL.php");
?>
	
	<?php
	 if($_POST){
		  	$queEmp = "INSERT INTO `veterinaria`.`infm_informacion_mascotas` (`infm_id`, `infm_nombre`, `infm_nacimiento`, `id_propietario`, `mas_infm_id`, `gen_infm_id`, `esm_infm_id`, `tps_infm_id`, `infm_fingreso`, `fam_infm_id`) 
		  	VALUES (NULL, '".$_POST["Nombre"]."', '".$_POST["Nacimiento"]."', '".$_POST["Propietario"]."', '".$_POST["Especie"]."', '".$_POST["Genero"]."', '".$_POST["Estado"]."', '".$_POST["EstadoClinico"]."', '".$_POST["FechaIngeso"]."', '".$_POST["Familia"]."')";
		  	//echo $queEmp;
			$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error()); 
			echo "<br><br><br><p><h2><b>Creacion de cliente mascota</b></h2></p>";
		 }
	 else{	 
	?>
	<div id="main1">
				<center><p>
	<form name="formulario" method="POST" onSubmit='return Connprobacion()' action="AddMascota.php" class="registro2">
	
	<h2><b>Añadir mascota</b></h2>
	<p><b>Nombre: </b><input type="text" name="Nombre">
	<p><b>Fecha de nacimiento (Año-Mes-Dia): </b><input type="text" name="Nacimiento">
	<p><b>Propietario: </b>
	<select name="Propietario">
		<?php
		$queEmp = "SELECT * FROM `prop_propietarios` ";
		$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error());
		while ($row = mysql_fetch_row($resEmp)){
			echo "<option value=".$row[0]." selected>".$row[1]."</option>";
			}
		?>
	</select>
	<p><b>Especie: </b>
	<select name="Especie">
		<?php
		$queEmp = "SELECT * FROM `mas_mascotas`";
		$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error());
		while ($row = mysql_fetch_row($resEmp)){
			echo "<option value=".$row[0]." selected>".$row[1]."</option>";
			}
		?>
	</select>
	<p><b>Familia: </b>
	<select name="Familia">
		<?php
		$queEmp = "SELECT * FROM `fam_familia`";
		$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error());
		while ($row = mysql_fetch_row($resEmp)){
			echo "<option value=".$row[0]." selected>".$row[1]."</option>";
			}
		?>
	</select>
	<p><b>Genero: </b>
	<select name="Genero">
		<?php
		$queEmp = "SELECT * FROM `gen_genero`";
		$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error());
		while ($row = mysql_fetch_row($resEmp)){
			echo "<option value=".$row[0]." selected>".$row[3]."</option>";
			}
		?>
	</select>
	
	<p><b>Estado control: </b>
	<select name="Estado">
		<?php
		$queEmp = "SELECT * FROM `esm_estado_mascotas`";
		$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error());
		while ($row = mysql_fetch_row($resEmp)){
			echo "<option value=".$row[0]." selected>".$row[1]."</option>";
			}
		?>
	</select>
	<p><b>Estado clinico: </b>
	<select name="EstadoClinico">
		<?php
		$queEmp = "SELECT * FROM `tps_tipo_salida`";
		$resEmp = mysql_query($queEmp, $conexion) or die(mysql_error());
		while ($row = mysql_fetch_row($resEmp)){
			echo "<option value=".$row[0]." selected>".$row[1]."</option>";
			}
		?>
	</select>
	<p><b>Fecha de ingreso (Año-Mes-Dia): </b><input type="text" name="FechaIngeso"></p>
	
	<p><input type="submit" value="Ingresar"></p>
	</form>
				</p></center>
       
     <?php
		}
     ?>  
       
           
<div id="footer1">
      <p>Copyright &copy;</p>
    </footer>
  </div>