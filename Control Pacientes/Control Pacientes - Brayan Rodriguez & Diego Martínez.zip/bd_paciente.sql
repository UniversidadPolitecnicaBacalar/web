-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-08-2015 a las 14:18:45
-- Versión del servidor: 5.6.24
-- Versión de PHP: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `bd_paciente`
--
CREATE DATABASE IF NOT EXISTS `bd_paciente` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `bd_paciente`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `area`
--

CREATE TABLE IF NOT EXISTS `area` (
  `id_area` int(11) NOT NULL,
  `descripcion` varchar(20) DEFAULT NULL,
  `id_umf` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `area`
--

INSERT INTO `area` (`id_area`, `descripcion`, `id_umf`) VALUES
(1, 'medicina Familiar', 1),
(2, 'Dentista', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `depuracion`
--

CREATE TABLE IF NOT EXISTS `depuracion` (
  `id_caja` int(11) NOT NULL,
  `nombre_caja` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `depuracion`
--

INSERT INTO `depuracion` (`id_caja`, `nombre_caja`) VALUES
(0, 'caja1'),
(1, '1'),
(2, 'Caja #2'),
(122, 'Caja #122'),
(144, 'Caja #144'),
(200, 'Caja #200');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE IF NOT EXISTS `empleado` (
  `id_empleado` int(11) NOT NULL,
  `nom_empleado` varchar(45) DEFAULT NULL,
  `usuario` varchar(20) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`id_empleado`, `nom_empleado`, `usuario`, `password`) VALUES
(1, 'Rodriguez Garcia Brayan', 'BARG', '81dc9bdb52d04dc20036dbd8313ed055'),
(2, 'Raul ', 'hhh', 'c20ad4d76fe97759aa27a0c99bff6710'),
(3, 'b', 'a', '4a8a08f09d37b73795649038408b5f33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE IF NOT EXISTS `estado` (
  `id_estado` int(11) NOT NULL,
  `nombre_estado` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`id_estado`, `nombre_estado`) VALUES
(1, 'Altas'),
(2, 'Depuracion'),
(3, 'Pasivos'),
(4, 'Defuncion');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente`
--

CREATE TABLE IF NOT EXISTS `paciente` (
  `id_paciente` int(11) NOT NULL,
  `nss` varchar(20) NOT NULL,
  `agregado` varchar(20) NOT NULL,
  `nom_paciente` varchar(25) NOT NULL,
  `apellido_paterno` varchar(25) NOT NULL,
  `apellido_materno` varchar(45) DEFAULT NULL,
  `fecha` date NOT NULL,
  `id_empleado` int(11) NOT NULL,
  `id_estado` int(11) NOT NULL,
  `id_area` int(11) NOT NULL,
  `id_caja` int(11) NOT NULL,
  `id_umf` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `paciente`
--

INSERT INTO `paciente` (`id_paciente`, `nss`, `agregado`, `nom_paciente`, `apellido_paterno`, `apellido_materno`, `fecha`, `id_empleado`, `id_estado`, `id_area`, `id_caja`, `id_umf`) VALUES
(1, '8877777777', '1M1996OR', 'Brayan', 'yopos', 'f', '0000-00-00', 1, 4, 2, 0, 2),
(6, '1', '3F1973OR', 'Brayan', 'Rodriguez', 'Garcia', '0000-00-00', 1, 1, 1, 0, 1),
(7, '1', '4M1999OR', 'Jorge', 'ffffffff', 'Roll', '0000-00-00', 1, 3, 2, 0, 2),
(8, '1232323213', '1M1996OR', 'Jall', 'Rodriguez', 'Garcia', '2015-08-04', 1, 2, 2, 1, 2),
(9, '8243234247', '1M2015OR', 'Harmn', 'Luna', 'Ramin', '0000-00-00', 1, 1, 2, 0, 2),
(10, '9999999999', '4M2007ES', 'Jorge', 'jhhj', 'vgy', '0000-00-00', 1, 4, 2, 0, 2),
(11, '2222222', '4M1997OR', 'NNNNNn', 'qqqqq', 'hola', '2015-08-04', 1, 3, 2, 0, 2),
(17, '134567891', '1M1996or', 'Brayan', 'Rodriguez', 'Garcia', '2015-08-04', 2, 1, 2, 0, 1),
(18, '2222222', '1M1996or', 'Brayan', 'Dorantes', 'Garcia', '2015-08-04', 2, 4, 2, 0, 2),
(20, '1223', '1M1997OR', 'Brayan', 'Rodriguez', 'Garcia', '2015-08-04', 2, 2, 2, 144, 2),
(21, '1234045', '1M1995OR', 'Panfilo', 'Se la', 'Come', '2015-08-05', 1, 1, 1, 0, 1),
(24, '1234567891', '1M0000OR', 'juan', 'perez', 'perez', '2015-08-05', 1, 1, 1, 0, 1),
(25, '14567891', '1M1234OR', 'juan', 'perez', 'perez', '2015-08-05', 1, 1, 1, 0, 1),
(26, '123457891', '1M1996OR', 'juan', 'perez', 'perez', '2015-08-05', 1, 2, 2, 1, 2),
(27, '1234567891', '3M1988OR', 'juan', 'perez', 'perez', '2015-08-05', 1, 2, 1, 122, 1),
(28, '4567891', '1M1996OR', 'juan', 'perez', 'perez', '2015-08-05', 1, 2, 2, 1, 2),
(29, '1234567891', '2013', 'Jorge', 'Yop', 'Hello', '2015-08-06', 1, 1, 1, 0, 1),
(30, '1234567891', '6M1962EC', 'Jorgeee', 'Jas', 'Perez', '2015-08-06', 1, 1, 1, 0, 1),
(31, '1', '1M2015OR', 'dsds', 'dsds', 'dsds', '2015-08-07', 1, 1, 1, 0, 1),
(32, '1234567890', '1M1991EC', 'jose', 'perez', 'perez', '2015-08-07', 1, 3, 2, 0, 3),
(33, '1234567890', '2M1996OR', 'jose', 'perez', 'perez', '2015-08-07', 1, 1, 2, 0, 1),
(34, '1234567892', '1M1997OR', 'jose', 'perez', 'perez', '2015-08-07', 1, 4, 2, 0, 2),
(51, '1234567895', '1M1990EC', 'juan', 'lopez', 'perez', '2015-08-07', 1, 2, 2, 1, 2),
(52, '8886660552', '1F1966OR', 'ALICIA CATALINA', 'GARCIA', 'TREJO', '2015-08-08', 1, 1, 1, 0, 1),
(65, '2213323213', '1M2015OR', 'fsfsd', 'dffffffffff', 'sdfsd', '2015-08-10', 1, 2, 1, 122, 1),
(66, '1244334343', '1F2000OR', 'Jua', 'jedshdshk', 'jdshkhcsk', '2015-08-10', 1, 2, 1, 200, 1),
(67, '1232233333', '4F1996OR', 'BRADSD', 'jdsjs', 'jkdsnjknsd', '2015-08-10', 1, 2, 1, 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `umf`
--

CREATE TABLE IF NOT EXISTS `umf` (
  `id_umf` int(11) NOT NULL,
  `nombre_umf` varchar(30) DEFAULT NULL,
  `direccion_umf` varchar(45) DEFAULT NULL,
  `tel_umf` varchar(17) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `umf`
--

INSERT INTO `umf` (`id_umf`, `nombre_umf`, `direccion_umf`, `tel_umf`) VALUES
(1, 'Unidad #1', 'Rg.96,mz90,lt.30', '938384959'),
(2, 'Unidad #2', 'rg.94,mz.40,lt30', '9393393'),
(3, 'Unidad #3', 'Rg.99,mz90,lt.30', '938385554'),
(4, 'Unidad #4', 'rg.91,mz.40,lt30', '3233243242'),
(5, 'Unidad #5', 'Rg.196,mz30,lt.10', '93835555'),
(6, 'Unidad #6', 'rg.1,mz.4,lt3', '555555555');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`id_area`), ADD KEY `fk_area_umf1_idx` (`id_umf`);

--
-- Indices de la tabla `depuracion`
--
ALTER TABLE `depuracion`
  ADD PRIMARY KEY (`id_caja`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`id_empleado`);

--
-- Indices de la tabla `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`id_estado`);

--
-- Indices de la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD PRIMARY KEY (`id_paciente`), ADD KEY `fk_paciente_empleado1_idx` (`id_empleado`), ADD KEY `fk_paciente_estado1_idx` (`id_estado`), ADD KEY `fk_paciente_area1_idx` (`id_area`), ADD KEY `fk_paciente_depuracion1_idx` (`id_caja`), ADD KEY `fk_paciente_umf1_idx` (`id_umf`);

--
-- Indices de la tabla `umf`
--
ALTER TABLE `umf`
  ADD PRIMARY KEY (`id_umf`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `area`
--
ALTER TABLE `area`
  MODIFY `id_area` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `empleado`
--
ALTER TABLE `empleado`
  MODIFY `id_empleado` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `estado`
--
ALTER TABLE `estado`
  MODIFY `id_estado` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `paciente`
--
ALTER TABLE `paciente`
  MODIFY `id_paciente` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT de la tabla `umf`
--
ALTER TABLE `umf`
  MODIFY `id_umf` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `area`
--
ALTER TABLE `area`
ADD CONSTRAINT `fk_area_umf1` FOREIGN KEY (`id_umf`) REFERENCES `umf` (`id_umf`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `paciente`
--
ALTER TABLE `paciente`
ADD CONSTRAINT `fk_paciente_area1` FOREIGN KEY (`id_area`) REFERENCES `area` (`id_area`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_paciente_depuracion1` FOREIGN KEY (`id_caja`) REFERENCES `depuracion` (`id_caja`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_paciente_empleado1` FOREIGN KEY (`id_empleado`) REFERENCES `empleado` (`id_empleado`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_paciente_estado1` FOREIGN KEY (`id_estado`) REFERENCES `estado` (`id_estado`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_paciente_umf1` FOREIGN KEY (`id_umf`) REFERENCES `umf` (`id_umf`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
